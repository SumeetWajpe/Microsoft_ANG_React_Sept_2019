import {Component, Input} from '@angular/core';

@Component({
    selector:'course',   
    templateUrl:"./course.component.html",
    styleUrls:['./course.style.css']
})
export class CourseComponent{
       @Input() coursedetails:CourseModel={name:"React",duration:"3 Days"};
}
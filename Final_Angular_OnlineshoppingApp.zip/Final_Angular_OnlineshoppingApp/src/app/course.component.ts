import {Component, Input} from '@angular/core';
import { CourseService } from './course.service';

@Component({
    selector:'course',   
    templateUrl:"./course.component.html",
    styleUrls:['./course.style.css']
   // ,   providers:[CourseService]

})
export class CourseComponent{
    isFree:boolean=false;
    isHighlighted:boolean=false;
    // styleToBeApplied:string = "courseStyle";
       @Input() coursedetails:CourseModel={name:"React",duration:3};
       constructor(public courseServObj:CourseService){

       }
       DeleteCourse(){
           this.courseServObj.deleteACourse(this.coursedetails.name)
       }
}
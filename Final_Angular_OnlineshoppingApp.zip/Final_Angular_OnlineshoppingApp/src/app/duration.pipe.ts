import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name:'duration'
})
export class DurationPipe implements PipeTransform{
        transform(inputDuration:number,args:string){
            return inputDuration + " " + args;
        }
}
import { Component, Input } from '@angular/core';
import { CourseService } from './course.service';

@Component({
    selector: 'listofcourses',
   templateUrl:'./listofcourses.component.html',
   styleUrls:['./listofcourses.style.css']
//    ,   providers:[CourseService]
})
export class ListOfCoursesComponent {
    heading:string="Online Courses";
    companyName:string="";
    courses:CourseModel[]=[];
    constructor(public courseServObj:CourseService){
            this.courses = this.courseServObj.getAllCourses();
    }
    ChangeHeading(){
        // update the model !
        this.heading = "Udemy !"
    }
       
}
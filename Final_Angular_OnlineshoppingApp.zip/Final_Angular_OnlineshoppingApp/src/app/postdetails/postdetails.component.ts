import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-postdetails',
  templateUrl: './postdetails.component.html',
  styleUrls: ['./postdetails.component.css']
})
export class PostdetailsComponent implements OnInit {

  postId:number;
  constructor(public currRoute:ActivatedRoute) { }

  ngOnInit() {
    this.currRoute.params.subscribe(p=>this.postId = p.id)
    
  }

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from'@angular/forms';
import  {HttpClientModule} from '@angular/common/http';
import {Routes,RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import {CourseComponent} from './course.component';
import { ListOfCoursesComponent } from './listofcourses.component';
import { DurationPipe } from './duration.pipe';
import { CourseService } from './course.service';
import { PostsComponent } from './posts/posts.component';
import { PostdetailsComponent } from './postdetails/postdetails.component';

const routes:Routes = [
  {path:"",component:ListOfCoursesComponent},
  {path:"posts",component:PostsComponent},
  {path:"postdetails/:id",component:PostdetailsComponent},
  {path:"**",redirectTo:'/'}

];

@NgModule({
  declarations: [
    AppComponent,CourseComponent,
    ListOfCoursesComponent,DurationPipe, PostsComponent, PostdetailsComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [CourseService],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';
import { PostsService } from '../posts.service';
import { Post } from './posts.model';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {
  posts:Post[] = [];
  constructor(public postServObj:PostsService) {
    console.log('Instance created !');
   }

  ngOnInit() {
    // Using Observables
  //  var observableOfPosts = this.postServObj.getAllPosts();
  //  observableOfPosts.subscribe(
  //   (response)=>{
  //     console.log('Within Posts COmponent !');
  //     console.log(this);
  //       this.posts = response;
  //   }
//)
// Using Promises
    var aPromise = this.postServObj.getAllPosts();
    aPromise.then(
      (response)=>{this.posts = response},
      (err)=>{console.log(err)}
    )

  }

}

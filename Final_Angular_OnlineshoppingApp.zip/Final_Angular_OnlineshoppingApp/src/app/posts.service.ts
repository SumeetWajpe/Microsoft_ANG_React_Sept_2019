import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Post } from './posts/posts.model';

@Injectable({
    providedIn:'root'
})
export class PostsService{
    constructor(public httpObj:HttpClient) {        
    }    
    // getAllPosts(){
    //     // AJAX request !
    //     // HttpClient
    //   return  this.httpObj.get<Post[]>("https://jsonplaceholder.typicode.com/posts");
    
    // }
    getAllPosts(){
        // AJAX request !
        // HttpClient
      return  this.httpObj.get<Post[]>("https://jsonplaceholder.typicode.com/posts").toPromise();
    
    }
}
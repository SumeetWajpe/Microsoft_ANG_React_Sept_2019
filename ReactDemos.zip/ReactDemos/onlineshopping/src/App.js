import React from 'react';
import logo from './logo.svg';
import './App.css';
import { ListofCourses } from './ListOfCourses.component';
import { Posts } from './posts.component';

// class App extends React.Component{
//   render(){
//     return (
//       <div className="container">
//           {/* <ListofCourses/> */}
//           <Posts/>
//       </div>
//     )
//   }
// }

let App = (props)=>{
  return <div className="container">
             {/* <ListofCourses/> */}

             {/* {props.name} */}
             <Posts/>
         </div>
}

export default App;

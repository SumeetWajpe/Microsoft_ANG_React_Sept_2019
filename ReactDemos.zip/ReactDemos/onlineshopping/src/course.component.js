import React from 'react';
export default class CourseComponent extends React.Component {
    constructor(props){
        super(props);
        this.state = {currCount:this.props.coursedetails.likes};
        // console.log('Within constructor !');
    }
    ChangeLikes(){
            // this.state.currCount+=1;
            this.setState({currCount:this.state.currCount+1});
            // console.log('Within ChangeLikes !');
    }
    render() {
        // console.log('Within render !');

        return <div className="col-md-4">
             <button className="btn btn-danger" 
             onClick={()=>this.props.DeleteHandler(this.props.coursedetails.id)}>
                <span className="glyphicon glyphicon-trash"></span>
            </button>
            <h3> {this.props.coursedetails.name} </h3>
           
            <img src={this.props.coursedetails.ImageUrl} height="200px" width="200px" /><br/>
            <b>Rating : </b> {this.props.coursedetails.rating} <br/>
            <b>Price : </b> {this.props.coursedetails.price} <br/>
            <b>Duration : </b> {this.props.coursedetails.duration} <br/>
            <b>Likes : </b> {this.state.currCount} <br/>

            <button className="btn btn-success" 
            onClick={this.ChangeLikes.bind(this)}>
                {this.state.currCount}
                    <span className="glyphicon glyphicon-thumbs-up"></span>
            </button> <br/>


        </div>
    }
}

export const PI = 3.14;
export const PIE = 3.14;

import React from 'react';
import axios from 'axios';

export class Posts extends React.Component{
    constructor(){
        super();
        this.state = {posts:[]};
    }
    componentDidMount(){
        // making an ajax request !
      let thePromise=  axios.get('https://jsonplaceholder.typicode.com/posts');
      thePromise.then(
          (response)=>{
                this.setState({posts:response.data})
          },
          (err)=> console.log(err)
      )
    }
    render(){
        var allPoststoBeCreated = this.state.posts.map(p=><li key={p.id}>{p.title}</li>);
        return <div>    
                        <div className="jumbotron">
                                <h1>List of Posts </h1>
                        </div>
                            <ul>
                                {allPoststoBeCreated}
                            </ul>
        </div>
    }
}